require './teste/jogo_teste.rb'
require './teste/bolao_teste.rb'
require './teste/arquivo_teste.rb'
require './teste/estatistica_do_jogo_teste.rb'
